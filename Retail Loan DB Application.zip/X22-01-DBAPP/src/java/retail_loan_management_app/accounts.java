/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package retail_loan_management_app;

import java.util.*;
import java.sql.*;
import java.sql.Date;

/**
 *
 * @author USER
 */
public class accounts {
    public Integer account_id;
    public Date date_created;
    public Integer branch_id; // fk
    
    // Database
    private String database = "jdbc:mysql://localhost:3306/retail_loan_db?useTimezone=true&serverTimezone=UTC&user=root&password=12345678";
    
    // default constructor
    public accounts() {}
    
    public int add_account() {
        try {
            // 1. Instantiate a connection variable
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");
            // 4. Prepare our INSERT Statement
            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(account_id) + 1 AS newCode FROM accounts");
            ResultSet result = pstmt.executeQuery();
            
            while (result.next()) {
                account_id = result.getInt("newCode");
            }
            
            pstmt = conn.prepareStatement("INSERT INTO accounts (account_id, date_created, branch_id) VALUES (?,?,?)");
            // 5. Supply the statement with values
            pstmt.setInt        (1, account_id);
            pstmt.setDate       (2, date_created);
            pstmt.setInt        (3, branch_id);
            // 6. Execute the SQL Statement
            pstmt.executeUpdate();   
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    // gets the list of accounts
    public ArrayList<Integer> list_accounts() {
        ArrayList<Integer> account_idlist = new ArrayList<> ();
        
        try {
            Connection conn = DriverManager.getConnection(database);
            PreparedStatement pstmt = conn.prepareStatement("SELECT a.account_id FROM accounts a ORDER BY a.account_id;");
            ResultSet results = pstmt.executeQuery();
            
            account_idlist.clear();
            
            while(results.next()) {
                account_idlist.add(results.getInt("account_id"));
            }
    
            pstmt.close();
            conn.close();

            return account_idlist;
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            return account_idlist;
        }
    }
    
    public int get_account() {
        try {
            // 1. Instantiate a connection variable
            Connection conn;
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM account WHERE account_id = ?");
            pstmt.setInt(1, account_id);
            ResultSet results = pstmt.executeQuery();

            if (results.next()) {
                date_created =      results.getDate("date_created");
                branch_id =         results.getInt("branch_id");
            } else {
                return 0;
            }

            conn.close();
            pstmt.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
}
