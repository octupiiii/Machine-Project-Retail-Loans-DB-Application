package retail_loan_management_app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class contactinformation {
    public int contact_information_id;
    public int contact_number;
    public String email_address;
    
    private String database = "jdbc:mysql://localhost:3306/retail_loan_db?useTimezone=true&serverTimezone=UTC&user=root&password=12345678";


    public contactinformation() {}

    public int addCI() {
        try {
            Connection conn = DriverManager.getConnection(database);
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(contact_information_id) + 1 AS newCode FROM contact_information");
            ResultSet result = pstmt.executeQuery();

            while (result.next()) {
            contact_information_id = result.getInt("newCode");
            }

            pstmt = conn.prepareStatement("INSERT INTO contact_information (contact_information_id, contact_number, email_address) VALUES (?,?,?)");

            pstmt.setInt(1, contact_information_id);
            pstmt.setInt(2, contact_number);
            pstmt.setString(3, email_address);

            pstmt.executeUpdate();

            conn.close();
            pstmt.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public static void main(String args[]) {
    }
}
