-- -----------------------------------------------------
-- Schema retail_loan_db
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS retail_loan_db;
CREATE SCHEMA IF NOT EXISTS retail_loan_db;
USE retail_loan_db;

-- -----------------------------------------------------
-- Table address
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS address (
  address_id 		INT(5) NOT NULL,
  street_no 		VARCHAR(45) NOT NULL,
  street_name 		VARCHAR(45) NOT NULL,
  barangay	 		VARCHAR(45) NOT NULL,
  city 				VARCHAR(45) NOT NULL,
  province 			VARCHAR(45) NOT NULL,
  zipcode 			INT NOT NULL,
  PRIMARY KEY 		(address_id)
);

-- -----------------------------------------------------
-- Table contact_information
-- -----------------------------------------------------
DROP TABLE IF EXISTS contact_information;
CREATE TABLE IF NOT EXISTS contact_information (
  contact_information_id 	INT NOT NULL,
  contact_number 			VARCHAR(20) NOT NULL,
  email_address 			VARCHAR(45) NOT NULL,
  PRIMARY KEY 				(contact_information_id)
);

-- -----------------------------------------------------
-- Table branch
-- -----------------------------------------------------
DROP TABLE IF EXISTS branch;
CREATE TABLE IF NOT EXISTS branch (
  branch_id 				INT(5) NOT NULL,
  branch_name 				VARCHAR(45) NOT NULL,
  address_id 				INT(5) NOT NULL,
  branch_status 			ENUM('active', 'closed') NOT NULL,
  opening_date 				DATE NOT NULL,
  manager_name 				VARCHAR(45) NOT NULL,
  contact_information_id 	INT NOT NULL,
  PRIMARY KEY 				(branch_id),
  INDEX  					(address_id ASC),
  INDEX  					(contact_information_id ASC),
  FOREIGN KEY 				(address_id)
    REFERENCES 				address (address_id),
  FOREIGN KEY 				(contact_information_id)
    REFERENCES 				contact_information (contact_information_id)
);

-- -----------------------------------------------------
-- Table accounts
-- -----------------------------------------------------
DROP TABLE IF EXISTS accounts;
CREATE TABLE IF NOT EXISTS accounts (
  account_id INT(5) NOT NULL,
  date_created DATE NOT NULL,
  branch_id INT(5) NOT NULL,
  PRIMARY KEY (account_id),
  INDEX (branch_id ASC),
  FOREIGN KEY (branch_id)
    REFERENCES branch (branch_id)
);

-- -----------------------------------------------------
-- Table customer
-- -----------------------------------------------------
DROP TABLE IF EXISTS customer;
CREATE TABLE IF NOT EXISTS customer (
  customer_id 				INT(5) NOT NULL,
  customer_firstname 		VARCHAR(45) NOT NULL,
  customer_mi 				VARCHAR(45) NOT NULL,
  customer_lastname 		VARCHAR(45) NOT NULL,
  birthdate 				DATE NOT NULL,
  sex 						ENUM('M', 'F') NOT NULL,
  picture 					VARCHAR(45) NOT NULL,
  billing_address 			INT(5) NOT NULL,
  account_id 				INT(5) NOT NULL,
  contact_information_id 	INT NOT NULL,
  PRIMARY KEY 				(customer_id),
  INDEX  					(account_id ASC),
  INDEX  					(billing_address ASC),
  INDEX  					(contact_information_id ASC),
  FOREIGN KEY 				(account_id)
    REFERENCES 				accounts (account_id),
  FOREIGN KEY 				(billing_address)
    REFERENCES 				address (address_id),
  FOREIGN KEY 				(contact_information_id)
    REFERENCES 				contact_information (contact_information_id)
);

-- -----------------------------------------------------
-- Table loan_information
-- -----------------------------------------------------
DROP TABLE IF EXISTS loan_information;
CREATE TABLE IF NOT EXISTS loan_information (
  loan_id 			INT(5) NOT NULL,
  loan_description  VARCHAR(45) NOT NULL,
  loan_term 		INT NOT NULL,
  loan_amount 		DECIMAL(10,2) NOT NULL,
  interest_rate 	DECIMAL(10,2) NOT NULL,
  loan_balance 		DECIMAL(10,2) NOT NULL,
  loan_status 		ENUM('pending', 'approved', 'denied', 'completed') NOT NULL,
  date_approved 	DATE NULL,
  date_completed	DATE NULL,
  account_id 		INT(5) NOT NULL,
  branch_id 		INT(5) NOT NULL,
  PRIMARY KEY 		(loan_id),
  INDEX 			(account_id ASC),
  INDEX 			(branch_id ASC),
  FOREIGN KEY 		(account_id)
    REFERENCES 		accounts (account_id),
  FOREIGN KEY 		(branch_id)
    REFERENCES 		branch (branch_id)
 );
-- -----------------------------------------------------
-- Table payments
-- -----------------------------------------------------
DROP TABLE IF EXISTS payments;
CREATE TABLE IF NOT EXISTS payments (
  reference_code 		INT NOT NULL,
  payment_date 			DATE NOT NULL,
  payment_method 		VARCHAR(45) NOT NULL,
  total_payment 		DECIMAL(10,2) NOT NULL,
  loan_id 				INT(5) NOT NULL,
  account_id 			INT(5) NOT NULL,
  branch_id 			INT(5) NOT NULL,
  PRIMARY KEY 			(reference_code),
  INDEX 				(account_id ASC),
  INDEX 				(branch_id ASC),
  INDEX 				(loan_id ASC),
  FOREIGN KEY 			(account_id)
    REFERENCES 			accounts (account_id),
  FOREIGN KEY 			(branch_id)
    REFERENCES 			branch (branch_id),
  FOREIGN KEY 			(loan_id)
    REFERENCES 			loan_information (loan_id)
);
-- -----------------------------------------------------
-- Add records to address
-- -----------------------------------------------------
INSERT INTO	address
	VALUES  (20011, 23, 'Daisy', 'Uno', 'Santa Rosa', 'Laguna', 7000),
			(20012, 54, 'Rose', 'Uno', 'Santa Rosa', 'Laguna', 7000),
			(20013, 12, 'Tulip', 'Dos', 'Santa Rosa', 'Laguna', 7000),
			(20014, 11, 'Sunflower', 'Dos', 'Santa Rosa', 'Laguna', 7000);

-- -----------------------------------------------------
-- Add records to contact_information
-- -----------------------------------------------------
INSERT INTO contact_information
VALUES	(011, '1234567890', 'banko_sampalok1@email.com'), 
     	(012, '9876543210', 'banko_sampalok2@email.com'),
		(013, '1112233445', 'banko_sampalok3@email.com'),
      	(014, '9123456789', 'juan.santos@email.com'),
      	(015, '9187635622', 'maria.santos@email.com'),
      	(016, '9451234567', 'jose.rodriguez@email.com'),
      	(017, '9823274412', 'anna.lim@email.com'),
      	(018, '9764537889', 'carlos.cruz@email.com');
        
-- -----------------------------------------------------
-- Add records to branch
-- -----------------------------------------------------
INSERT INTO branch
	VALUES	(10001, 'Banko Sampaloc 1', 20011, 'active', '2023-11-16', 'Mark Lee', 011),
			(10002, 'Banko Sampaloc 2', 20012, 'closed', '2023-11-17', 'Joshua Hong', 012),
			(10003, 'Banko Sampaloc 3', 20013, 'active', '2023-11-18', 'Pikachu', 013);
            
-- -----------------------------------------------------
-- Add records to accounts
-- -----------------------------------------------------
INSERT INTO	accounts
	VALUES  (30011, '2020-06-22', 10001),
			(30012, '2020-06-22', 10003),
			(30013, '2020-09-18', 10002),
			(30014, '2021-01-23', 10001),
			(30015, '2021-04-29', 10002);
        
-- -----------------------------------------------------
-- Add records to customer
-- -----------------------------------------------------
INSERT INTO customer
	VALUES  (10011, 'Juan', 'D', 'Santos', '1990-05-15', 'M', 'pic1.jpg', 20011, 30011, 014),
			(10012, 'Maria', 'T', 'Santos', '1985-08-22', 'F', 'pic2.jpg', 20011, 30012, 015),
			(10013, 'Jose', 'R', 'Rodriguez', '1982-11-10', 'M', 'pic3.jpg', 20012,  30013, 016),
			(10014, 'Anna', 'M', 'Lim', '2000-10-25', 'F', 'pic4.jpg', 20013,  30014, 017),
			(10015, 'Carlos', 'S', 'Cruz', '1999-05-11', 'M', 'pic5.jpg', 20014,  30015, 018);

-- -----------------------------------------------------
-- Add records to payments
-- -----------------------------------------------------
INSERT INTO loan_information
	VALUES	(70011, 'Car loan', 8, 35000, .03, 0, 'completed', '2014-10-05', '2022-10-05', 30011, 10003),
			(70012, 'Personal loan', 6, 45000, .02, 0, 'completed', '2016-10-12', '2022-10-12', 30015, 10002),
			(70013, 'Home improvement loan', 10, 75000, .03, 0, 'completed', '2013-11-15', '2023-11-15', 30012, 10001),
			(70014, 'Education loan', 3, 18000, .02, 0, 'completed', '2020-11-20', '2023-11-20', 30014, 10002),
			(70015, 'Personal loan', 7, 50000, .05, 49000, 'pending', null, null, 30011, 10001),
			(70016, 'Home loan', 12, 100000, .05, 99500, 'approved', '2023-11-10', null, 30012, 10003),
			(70017, 'Personal loan', 5, 25000, .05, 22900, 'approved', '2023-11-15', null, 30013, 10002),
			(70018, 'Education loan', 1, 12000, .05, 11000, 'approved', '2023-11-28', null, 30011, 10001),
            (70019, 'Car loan', 1, 500500, .05, 11000, 'approved', '2023-11-28', null, 30011, 10001);
    
-- -----------------------------------------------------
-- Add records to payments
-- -----------------------------------------------------
INSERT INTO payments
	VALUES	(50001, '2023-12-10', 'Online', 1000, 70011, 30011, 10001),
			(50002, '2023-12-12', 'Online', 2100, 70013, 30013, 10002),
			(50003, '2023-12-16', 'Online', 500, 70012, 30012, 10003),
			(50004, '2024-01-11', 'Online', 1000, 70014, 30011, 10001);
