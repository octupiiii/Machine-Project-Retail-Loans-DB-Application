package retail_loan_management_app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class address {
    public int address_id;
    public int street_no;
    public String street_name;
    public String barangay;
    public String city;
    public String province;
    public int zipcode;
    
    private String database = "jdbc:mysql://localhost:3306/retail_loan_db?useTimezone=true&serverTimezone=UTC&user=root&password=12345678";

    public address() {}

    public int addAddress() {
        try {
            Connection conn = DriverManager.getConnection(database);
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(address_id) + 1 AS newCode FROM address");
            ResultSet result = pstmt.executeQuery();

            while (result.next()) {
            address_id = result.getInt("newCode");
            }

            pstmt = conn.prepareStatement("INSERT INTO address (address_id, street_no, street_name, barangay, city, province, zipcode) VALUES (?,?,?,?,?,?,?)");

            pstmt.setInt(1, address_id);
            pstmt.setInt(2, street_no);
            pstmt.setString(3, street_name);
            pstmt.setString(4, barangay);
            pstmt.setString(5, city);
            pstmt.setString(6, province);
            pstmt.setInt(7, zipcode);

            pstmt.executeUpdate();

            conn.close();
            pstmt.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public static void main(String args[]) {
    }
}