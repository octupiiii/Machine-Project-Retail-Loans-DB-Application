/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retail_loan_management_app;

import java.util.*;
import java.sql.*;
import java.sql.Date;

/**
 *
 * @author ccslearner
 */
public class loan_information {
    
    /* Enums */
    public enum Status {
        pending,
        approved,
        denied,
        completed
    }

    public int loan_id;
    public String loan_description;
    public int loan_term;
    public double loan_amount; 
    public double interest_rate;
    public double loan_balance;
    public Status loan_status;
    public Date date_approved;
    public Date date_completed;
    public int account_id;
    public int branch_id;
    
    ArrayList<Integer> loan_idlist = new ArrayList<>();
    
    private String database = "jdbc:mysql://localhost:3306/retail_loan_db?useTimezone=true&serverTimezone=UTC&user=root&password=12345678";
    
    public loan_information() {}
    
    public int add_loan_info() {
        try {
            // 1. Instantiate a connection variable
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");
            // 4. Prepare our INSERT Statement
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(loan_id) + 1 AS newId FROM loan_information");
            ResultSet result = pstmt.executeQuery();
            
            while (result.next()) {
                loan_id = result.getInt("newId");
            }
            
            pstmt = conn.prepareStatement("INSERT INTO loan_information (loan_id, loan_description, loan_term, loan_amount, interest_rate, loan_balance, loan_status, date_approved, date_completed, account_id, branch_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
            // 5. Supply the statement with values
            pstmt.setInt(1, loan_id);
            pstmt.setString(2, loan_description);
            pstmt.setInt(3, loan_term);
            pstmt.setDouble(4, loan_amount);
            pstmt.setDouble(5, interest_rate);
            loan_balance = loan_amount;
            pstmt.setDouble(6, loan_balance);
            loan_status = loan_status.pending;
            pstmt.setString(7, loan_status.name());
            date_approved = null;
            date_completed = null;
            pstmt.setDate(8, date_approved);
            pstmt.setDate(9, date_completed);
            pstmt.setInt(10, account_id);
            pstmt.setInt(11, branch_id);
            
            // 6. Execute the SQL Statement
            pstmt.executeUpdate();   
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int update_loan_info() {
        
        try {
            // 1. Instantiate a connection variable
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("UPDATE loan_information SET loan_description = ?, loan_term = ?, loan_amount = ?, interest_rate = ?, loan_balance = ?, loan_status = ?, date_approved = ?, date_completed = ?, account_id = ?, branch_id = ? WHERE loan_id = ?");
            // 5. Supply the statement with values
            pstmt.setInt(11, loan_id);
            pstmt.setString(1, loan_description);
            pstmt.setInt(2, loan_term);
            pstmt.setDouble(3, loan_amount);
            pstmt.setDouble(4, interest_rate);
            pstmt.setDouble(5, loan_balance);
            pstmt.setString(6, loan_status.name());
            pstmt.setDate(7, date_approved);
            pstmt.setDate(8, date_completed);
            pstmt.setInt(9, account_id);
            pstmt.setInt(10, branch_id);
            pstmt.executeUpdate();
        
            conn.close();
            pstmt.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
        
    }
    
    public ArrayList<Integer> list_loan_id() {

        try {
            Connection conn = DriverManager.getConnection(database);
            PreparedStatement pstmt = conn.prepareStatement("SELECT loan_id FROM loan_information ORDER BY loan_id");
            ResultSet results = pstmt.executeQuery();

            loan_idlist.clear();

            while(results.next()) {
                loan_idlist.add(results.getInt("loan_id"));
            }

            pstmt.close();
            conn.close();

            return loan_idlist;
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            return loan_idlist;
        }
    }
    
    public int get_loan_info() {
        
        try {
            // 1. Instantiate a connection variable
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");
            // 4. Prepare our INSERT Statement
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM loan_information WHERE loan_id = ?");
            pstmt.setInt(1, loan_id);
            ResultSet result = pstmt.executeQuery();
            
            if (result.next()) {
                loan_id = result.getInt("loan_id");
                loan_description = result.getString("loan_description");
                loan_term = result.getInt("loan_term");
                loan_amount = result.getDouble("loan_amount");
                interest_rate = result.getDouble("interest_rate");
                loan_balance = result.getDouble("loan_balance");
                loan_status = Status.valueOf(result.getString("loan_status"));
                date_approved = result.getDate("date_approved");
                date_completed = result.getDate("date_completed");
                account_id = result.getInt("account_id");
                branch_id = result.getInt("branch_id");
            } else {
                return 0;
            }
        
            conn.close();
            pstmt.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int delete_loan_information() {
        try {
            Connection conn = DriverManager.getConnection(database);
            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM loan_information WHERE loan_id=?");
            pstmt.setInt(1, loan_id);
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();

            return 1;
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
     public ArrayList<Integer> listLoanByStatus(String status) {

        try {
            Connection conn = DriverManager.getConnection(database);
            String query;

            if ("pending".equals(status) || "approved".equals(status) ||
                "denied".equals(status) || "completed".equals(status)) {
                // If a specific status is selected
                query = "SELECT loan_id FROM loan_information WHERE loan_status = ?";
            } else {
                // If "all" is selected, show all branches
                query = "SELECT loan_id FROM loan_information";
            }

            PreparedStatement pstmt = conn.prepareStatement(query);

            if ("pending".equals(status) || "approved".equals(status) ||
                "denied".equals(status) || "completed".equals(status)) {
                pstmt.setString(1, status);
            }

            ResultSet results = pstmt.executeQuery();
            
            loan_idlist.clear();
            
            while (results.next()) {
                loan_idlist.add(results.getInt("loan_id"));
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return loan_idlist;
    }
     
    public ArrayList<Integer> list_loan_idByMonth() {
        ArrayList<Integer> monthlylist_loanid = new ArrayList<> ();
        try {
        Connection conn = DriverManager.getConnection(database);
        // Use MONTH() function to extract the month from the date_approved column
        PreparedStatement pstmt = conn.prepareStatement("SELECT loan_id FROM loan_information WHERE loan_status = 'approved' ORDER BY date_approved;");

        ResultSet results = pstmt.executeQuery();

        while(results.next()) {
            monthlylist_loanid.add(results.getInt("loan_id"));
        }

        pstmt.close();
        conn.close();

        return monthlylist_loanid;
    } catch(SQLException e) {
        System.out.println(e.getMessage());
        return monthlylist_loanid;
    }
}
    
    public ArrayList<Integer> list_loan_idByMonthFilter(int f_month, int f_branch_id, double f_amount, int f_account_id) {
    ArrayList<Integer> monthlylist_loanid = new ArrayList<> ();
    
    try {
        Connection conn = DriverManager.getConnection(database);
        
        StringBuilder sql_query = new StringBuilder("SELECT loan_id FROM loan_information WHERE loan_status = 'approved'");
        
        // conditions
        if (f_month > 0) {
            sql_query.append(" AND MONTH(date_approved) = ?");
        } 
                
        if (f_branch_id > 0) {
            sql_query.append(" AND branch_id = ?");
        }
        if (f_amount > 0) {
            if (f_amount == 1){
                sql_query.append(" AND loan_amount < 500001");
            } else if (f_amount == 2) {
                sql_query.append(" AND loan_amount > 500000 AND loan_amount < 1000001");
            } else if (f_amount == 3) {
                sql_query.append(" AND loan_amount > 1000000 AND loan_amount < 5000001");
            } else if (f_amount == 4) {
                sql_query.append(" AND loan_amount > 5000000");
            }
        }
        if (f_account_id > 0) {
            sql_query.append(" AND account_id = ?");
        }
        
        sql_query.append(" ORDER BY date_approved");
        
        PreparedStatement pstmt = conn.prepareStatement(sql_query.toString());
        
        // set the parameters
        int i = 1;
        if (f_month > 0) {
            pstmt.setInt(i++, f_month);
        }
        
        if (f_branch_id > 0) {
            pstmt.setInt(i++, f_branch_id);
        }
        //if (f_amount > 0) {
        //    pstmt.setDouble(i++, f_amount);
        //}
        if (f_account_id > 0) {
            pstmt.setInt(i++, f_account_id);
        }

        ResultSet results = pstmt.executeQuery();
        while(results.next()) {
            monthlylist_loanid.add(results.getInt("loan_id"));
        }

        pstmt.close();
        conn.close();

        return monthlylist_loanid;
    } catch(SQLException e) {
        System.out.println(e.getMessage());
        return monthlylist_loanid;
    }
    
    }
    
    public ArrayList<Integer> list_loan_idByMonthFilter(int f_month, int f_branch_id, int f_account_id) {
    ArrayList<Integer> monthlylist_loanid = new ArrayList<> ();
    
    try {
        Connection conn = DriverManager.getConnection(database);
        
        StringBuilder sql_query = new StringBuilder("SELECT loan_id FROM loan_information WHERE loan_status = 'completed'");
        
        // conditions
        if (f_month > 0) {
            sql_query.append(" AND MONTH(date_completed) = ?");
        } 
                
        if (f_branch_id > 0) {
            sql_query.append(" AND branch_id = ?");
        }
        
        if (f_account_id > 0) {
            sql_query.append(" AND account_id = ?");
        }
        
        sql_query.append(" ORDER BY loan_id");
        
        PreparedStatement pstmt = conn.prepareStatement(sql_query.toString());
        
        // set the parameters
        int i = 1;
        if (f_month > 0) {
            pstmt.setInt(i++, f_month);
        }
        
        if (f_branch_id > 0) {
            pstmt.setInt(i++, f_branch_id);
        }
        //if (f_amount > 0) {
        //    pstmt.setDouble(i++, f_amount);
        //}
        if (f_account_id > 0) {
            pstmt.setInt(i++, f_account_id);
        }

        ResultSet results = pstmt.executeQuery();
        while(results.next()) {
            monthlylist_loanid.add(results.getInt("loan_id"));
        }

        pstmt.close();
        conn.close();

        return monthlylist_loanid;
    } catch(SQLException e) {
        System.out.println(e.getMessage());
        return monthlylist_loanid;
    }
    
    }
    public ArrayList<Integer> list_loanaccount_id() {
        ArrayList<Integer> loanaccountid_list = new ArrayList<> ();
        try {
            Connection conn = DriverManager.getConnection(database);
            PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT account_id FROM loan_information;");
            ResultSet results = pstmt.executeQuery();

            while(results.next()) {
                loanaccountid_list.add(results.getInt("account_id"));
            }

            pstmt.close();
            conn.close();

            return loanaccountid_list;
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            return loanaccountid_list;
        }
    }
    
    public static void main (String args[]) {
        // test loan_information.java   
        
    }
    
}
