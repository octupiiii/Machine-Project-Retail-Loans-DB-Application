/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package retail_loan_management_app;

import java.util.*;
import java.sql.*;
import java.sql.Date;

/**
 *
 * @author USER
 */
public class customer {
    /* Enums */
    public enum Sex {
        F,
        M
    }
    
    // Fields of Assets
    public Integer customer_id; // Primary Key
    public String customer_firstname;
    public String customer_mi;
    public String customer_lastname;
    public Date   birthdate;
    public Sex sex;
    public String picture;
    
    // Foreign Keys
    public Integer billing_address; // id 
    public Integer account_id;
    public Integer contact_information_id;
    
    //lists
    public ArrayList<Integer> customer_idlist = new ArrayList<>();
    
    // Database
    private String database = "jdbc:mysql://localhost:3306/retail_loan_db?useTimezone=true&serverTimezone=UTC&user=root&password=12345678";
    
    // default constructor
    public customer() {}
    
    public int add_record() {
        try {
            // 1. Instantiate a connection variable
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");
            // 4. Prepare our INSERT Statement
            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(customer_id) + 1 AS newCode FROM customer");
            ResultSet result = pstmt.executeQuery();
            
            while (result.next()) {
                customer_id = result.getInt("newCode");
            }
            
            System.out.println(customer_id);
            //System.out.println(account_id);
            //System.out.println(contact_information_id);
            
            pstmt = conn.prepareStatement("INSERT INTO customer (customer_id, customer_firstname, customer_mi, customer_lastname, birthdate, sex, picture, billing_address, account_id, contact_information_id) VALUES (?,?,?,?,?,?,?,?,?,?)");
            // 5. Supply the statement with values
            pstmt.setInt        (1, customer_id);
            pstmt.setString     (2, customer_firstname);
            pstmt.setString     (3, customer_mi);
            pstmt.setString     (4, customer_lastname);
            pstmt.setDate       (5, birthdate);
            pstmt.setString     (6, sex.name());
            pstmt.setString     (7, picture);
            pstmt.setInt        (8, billing_address);
            pstmt.setInt        (9, account_id);
            pstmt.setInt        (10, contact_information_id);
            // 6. Execute the SQL Statement
            pstmt.executeUpdate();   
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public ArrayList<Integer> list_deletable_customers() {

        ArrayList<Integer> deletable_customerslist = new ArrayList<> ();

        try {
            Connection conn = DriverManager.getConnection(database);
            PreparedStatement pstmt = conn.prepareStatement("SELECT c.customer_id FROM customer c ORDER BY c.customer_id;");
            ResultSet results = pstmt.executeQuery();

            deletable_customerslist.clear();

            while(results.next()) {
                deletable_customerslist.add(results.getInt("customer_id"));
            }

            pstmt.close();
            conn.close();

            return deletable_customerslist;
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            return deletable_customerslist;
        }
    }
    
    // gets the list of customers
    public ArrayList<Integer> list_customers() {
        ArrayList<Integer> customer_idlist = new ArrayList<> ();
        
        try {
            Connection conn = DriverManager.getConnection(database);
            PreparedStatement pstmt = conn.prepareStatement("SELECT c.customer_id FROM customer c ORDER BY c.customer_id;");
            ResultSet results = pstmt.executeQuery();
            
            customer_idlist.clear();
            
            while(results.next()) {
                customer_idlist.add(results.getInt("customer_id"));
            }
    
            pstmt.close();
            conn.close();

            return customer_idlist;
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            return customer_idlist;
        }
    }
    
    public ArrayList<Integer> listCustomersByStatus(String status) {
        ArrayList<Integer> customer_idlist = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection(database);
            String query;

            if ("M".equals(status) || "F".equals(status)) {
                // If a specific status is selected
                query = "SELECT customer_id FROM customer WHERE sex = ?";
            } else {
                // If "all" is selected, show all branches
                query = "SELECT customer_id FROM customer";
            }

            PreparedStatement pstmt = conn.prepareStatement(query);

            if ("M".equals(status) || "F".equals(status)) {
                pstmt.setString(1, status);
            }

            ResultSet results = pstmt.executeQuery();

            while (results.next()) {
                customer_idlist.add(results.getInt("customer_id"));
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return customer_idlist;
    }
    
    public int get_customer() {

        try {
            // 1. Instantiate a connection variable
            Connection conn;
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM customer WHERE customer_id = ?");
            pstmt.setInt(1, customer_id);
            ResultSet results = pstmt.executeQuery();

            if (results.next()) {
                customer_firstname =        results.getString("customer_firstname");
                customer_mi =               results.getString("customer_mi");
                customer_lastname =         results.getString("customer_lastname");
                birthdate =                 results.getDate("birthdate");
                sex =                       Sex.valueOf(results.getString("sex"));
                picture =                   results.getString("picture");
                billing_address =           results.getInt("billing_address");
                account_id =                results.getInt("account_id");
                contact_information_id =    results.getInt("contact_information_id");
            } else {
                return 0;
            }

            conn.close();
            pstmt.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int update_record() {
        try {
            Connection conn = DriverManager.getConnection(database);
            PreparedStatement pstmt = conn.prepareStatement("UPDATE customer SET customer_firstname=?, customer_mi=?, customer_lastname=?, birthdate=?, sex=?, picture=?, billing_address=?, account_id=?, contact_information_id=? WHERE customer_id = ?");

            pstmt.setString (1, customer_firstname);
            pstmt.setString (2, customer_mi);
            pstmt.setString (3,customer_lastname);
            pstmt.setDate   (4, birthdate);
            pstmt.setString (5, sex.name());
            pstmt.setString (6, picture);
            pstmt.setInt    (7, billing_address);
            pstmt.setInt    (8, account_id);
            pstmt.setInt    (9, contact_information_id);
            pstmt.setInt    (10, customer_id);

            pstmt.executeUpdate();
            pstmt.close();
            conn.close();

            return 1;
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int del_record() {
        try {
            Connection conn = DriverManager.getConnection(database);
            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM customer WHERE customer_id=?");
            pstmt.setInt(1, customer_id);
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();

            return 1;
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public static void main (String args[]) {
        // test customer.java   
        customer C = new customer();

        System.out.println(C.add_record());
    }
}
