/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retail_loan_management_app;

import java.sql.*;
import java.util.*;
import java.sql.Date;
import java.time.LocalDate;

public class branch {
    
        
    public enum Status {
        active,
        closed
    }

    public int branch_id;
    public String branch_name;
    public int address_id;
    public Status branch_status;
    public Date opening_date;
    public String manager_name;
    public int contact_information_id;

    public ArrayList<Integer> a_branch_id = new ArrayList<>();
    public ArrayList<String> a_branch_name = new ArrayList<>();
    public ArrayList<Integer> a_address_id = new ArrayList<>();
    public ArrayList<String> a_branch_status = new ArrayList<>();
    public ArrayList<String> a_opening_date = new ArrayList<>();
    public ArrayList<String> a_manager_name = new ArrayList<>();
    public ArrayList<Integer> a_contact_infomation_id = new ArrayList<>();

    private String database = "jdbc:mysql://localhost:3306/retail_loan_db?useTimezone=true&serverTimezone=UTC&user=root&password=12345678";
    
    public branch() {
    }
    
    public int add_branch() {
       try {
            // 1. Instantiate a connection variable
            Connection conn;
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(branch_id) + 1 AS newCode FROM branch");
            ResultSet result = pstmt.executeQuery();

            while (result.next()) {
                branch_id = result.getInt("newCode");
            }

           pstmt = conn.prepareStatement("INSERT INTO branch (branch_id, branch_name, address_id, branch_status, opening_date, manager_name, contact_information_id) VALUES (?,?,?,?,?,?,?)");

            pstmt.setInt(1, branch_id);
            pstmt.setString(2, branch_name);
            pstmt.setInt(3, address_id);
            pstmt.setString(4, branch_status.name());
            pstmt.setDate(5, opening_date);
            pstmt.setString(6, manager_name);
            pstmt.setInt(7, contact_information_id);
            pstmt.executeUpdate();

            conn.close();
            pstmt.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    public ArrayList<Integer> list_available_branches() {

        ArrayList<Integer> available_branchlist = new ArrayList<> ();

        try {
            Connection conn = DriverManager.getConnection(database);
            PreparedStatement pstmt = conn.prepareStatement("SELECT b.branch_id FROM branch b ORDER BY b.branch_id;");
            ResultSet results = pstmt.executeQuery();

            available_branchlist.clear();

            while(results.next()) {
                available_branchlist.add(results.getInt("branch_id"));
            }

            pstmt.close();
            conn.close();

            return available_branchlist;
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            return available_branchlist;
        }
    }
    
    public int del_branch() {
        try {
            Connection conn;
                    conn = DriverManager.getConnection(database);
            PreparedStatement pstmt;
                    pstmt = conn.prepareStatement("DELETE FROM branch WHERE branch_id=?");
            pstmt.setInt(1, branch_id);
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();

            return 1;
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
     public ArrayList<Integer> listBranches() {
        ArrayList<Integer> branchIds = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection(database);
            PreparedStatement pstmt = conn.prepareStatement("SELECT branch_id FROM branch");
            ResultSet results = pstmt.executeQuery();

            while (results.next()) {
                branchIds.add(results.getInt("branch_id"));
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return branchIds;
    }

    public void getBranch() {
        try {
            Connection conn = DriverManager.getConnection(database);
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM branch WHERE branch_id = ?");
            pstmt.setInt(1, branch_id);
            ResultSet results = pstmt.executeQuery();

            if (results.next()) {
                // Assuming your class has corresponding setters
                branch_name = results.getString("branch_name");
                address_id = results.getInt("address_id");
                branch_status = Status.valueOf(results.getString("branch_status"));
                opening_date = results.getDate("opening_date");
                manager_name = results.getString("manager_name");
                contact_information_id = results.getInt("contact_information_id");
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public int get_branch() {
    try {
        // 1. Instantiate a connection variable
        Connection conn;
        // 2. Connect to your DB
        conn = DriverManager.getConnection(database);
        // 3. Indicate a notice of successful connection
        System.out.println("Connection Successful");

        PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM branch WHERE branch_id = ?");
        pstmt.setInt(1, branch_id);
        ResultSet result = pstmt.executeQuery();

        if (result.next()) {
            branch_id = result.getInt("branch_id");
            branch_name = result.getString("branch_name");
            address_id = result.getInt("address_id");
            branch_status = branch.Status.valueOf(result.getString("branch_status"));
            opening_date = result.getDate("opening_date");
            manager_name = result.getString("manager_name");
            contact_information_id = result.getInt("contact_information_id");
        } else {
            return 0;
        }

        System.out.println(branch_id);
        System.out.println(branch_name);
        System.out.println(address_id);
        System.out.println(branch_status);
        System.out.println(opening_date);
        System.out.println(manager_name);
        System.out.println(contact_information_id);

        conn.close();
        pstmt.close();
        return 1;
    } catch (Exception e) {
        System.out.println(e.getMessage());
        return 0;
    }
}
    
    public int update_branch() {
       try {
            // 1. Instantiate a connection variable
            Connection conn;
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("UPDATE branch SET branch_name=?, address_id=?, branch_status=?, opening_date=?, manager_name=?, contact_information_id=? WHERE branch_id=?");
            

            pstmt.setString(1, branch_name);
            pstmt.setInt(2, address_id);
            pstmt.setString(3, branch_status.name());
            pstmt.setDate(4, opening_date);
            pstmt.setString(5, manager_name);
            pstmt.setInt(6, contact_information_id);
            pstmt.setInt(7, branch_id);

            pstmt.executeUpdate();

            conn.close();
            pstmt.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
     public ArrayList<Integer> listBranchesByStatus(String status) {
        ArrayList<Integer> branchIds = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection(database);
            String query;

            if ("active".equals(status) || "closed".equals(status)) {
                // If a specific status is selected
                query = "SELECT branch_id FROM branch WHERE branch_status = ?";
            } else {
                // If "all" is selected, show all branches
                query = "SELECT branch_id FROM branch";
            }

            PreparedStatement pstmt = conn.prepareStatement(query);

            if ("active".equals(status) || "closed".equals(status)) {
                pstmt.setString(1, status);
            }

            ResultSet results = pstmt.executeQuery();

            while (results.next()) {
                branchIds.add(results.getInt("branch_id"));
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return branchIds;
    }
    



        
    public static void main(String[] args) {
    
        
    branch branchToUpdate = new branch();
    int status = branchToUpdate.update_branch();

    // Check the status result
    if (status == 1) {
        System.out.println("Branch updated successfully!");
    } else {
        System.out.println("Failed to update branch.");
    }
    }
    
}