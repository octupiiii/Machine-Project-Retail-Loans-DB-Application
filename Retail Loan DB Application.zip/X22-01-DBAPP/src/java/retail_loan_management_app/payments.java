package retail_loan_management_app;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ccslearner
 */

import java.util.*;
import java.sql.*;
import java.sql.Date;

public class payments {
    
    public int reference_code;
    public Date payment_date;
    public String payment_method;
    public double total_payment;
    public int loan_id;
    public int account_id;
    public int branch_id;
    public double loan_balance;
    public double newBalance;
    public String loan_status;
    
    public ArrayList<Integer> reference_codelist = new ArrayList<>();
    public ArrayList<String> payment_datelist = new ArrayList<>();
    public ArrayList<String> payment_methodlist = new ArrayList<>();
    public ArrayList<Double> total_paymentlist = new ArrayList<>();
    public ArrayList<Integer> loan_idlist = new ArrayList<>();
    public ArrayList<Integer> account_idlist = new ArrayList<>();
    public ArrayList<Integer> branch_idlist = new ArrayList<>();
    
    private String database = "jdbc:mysql://localhost:3306/retail_loan_db?useTimezone=true&serverTimezone=UTC&user=root&password=12345678";
    
    public payments() {}
    
    public int add_payment() {
        
        try {
            // 1. Instantiate a connection variable
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(reference_code) + 1 AS newCode FROM payments");
            ResultSet result = pstmt.executeQuery();
            
            while (result.next()) {
                reference_code = result.getInt("newCode");
            }
            
            pstmt = conn.prepareStatement("INSERT INTO payments (reference_code, payment_date, payment_method, total_payment, loan_id, account_id, branch_id) VALUE (?,?,?,?,?,?,?)");
            
            pstmt.setInt(1, reference_code);
            pstmt.setDate(2, payment_date);
            pstmt.setString(3, payment_method);
            pstmt.setDouble(4, total_payment);
            pstmt.setInt(5, loan_id);
            pstmt.setInt(6, account_id);
            pstmt.setInt(7, branch_id);
            pstmt.executeUpdate();
            
            conn.close();
            pstmt.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
        
    }
    
    public int update_payment() {
        
        try {
            // 1. Instantiate a connection variable
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("UPDATE payments SET payment_date = ?, payment_method = ?, total_payment = ?, loan_id = ?, account_id = ?, branch_id = ? WHERE reference_code = ?");
            
            pstmt.setInt(7, reference_code);
            pstmt.setDate(1, payment_date);
            pstmt.setString(2, payment_method);
            pstmt.setDouble(3, total_payment);
            pstmt.setInt(4, loan_id);
            pstmt.setInt(5, account_id);
            pstmt.setInt(6, branch_id);
            pstmt.executeUpdate();
        
            conn.close();
            pstmt.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
        
    }
    
     public int make_payment() {
        try {
            // 1. Instantiate a connection variable
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/retail_loan_db?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");
            
            // Retrieve the loan status for the given loan_id
            PreparedStatement loanStatusStmt = conn.prepareStatement("SELECT loan_status FROM loan_information WHERE loan_id = ?");
            loanStatusStmt.setInt(1, loan_id);
            ResultSet loanStatusResult = loanStatusStmt.executeQuery();

            String loanStatus = "";

            if (loanStatusResult.next()) {
                loanStatus = loanStatusResult.getString("loan_status");
            }

            loanStatusStmt.close();

            // Only update the loan information if the current status is not "pending" or "denied"
            if (!"pending".equals(loanStatus) && !"denied".equals(loanStatus) && !"completed".equals(loanStatus)) {
                // Existing code to get the next reference code
                PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(reference_code) + 1 AS newCode FROM payments");
                ResultSet result = pstmt.executeQuery();
                
                while (result.next()) {
                    reference_code = result.getInt("newCode");
                }
                
                // Existing code to insert payment details
                pstmt = conn.prepareStatement("INSERT INTO payments (reference_code, payment_date, payment_method, total_payment, loan_id, account_id, branch_id) VALUE (?,?,?,?,?,?,?)");
                
                pstmt.setInt(1, reference_code);
                pstmt.setDate(2, payment_date);
                pstmt.setString(3, payment_method);
                pstmt.setDouble(4, total_payment);
                pstmt.setInt(5, loan_id);
                pstmt.setInt(6, account_id);
                pstmt.setInt(7, branch_id);
                pstmt.executeUpdate();

                // Retrieve the loan balance for the given loan_id
                PreparedStatement loanBalanceStmt = conn.prepareStatement("SELECT loan_balance FROM loan_information WHERE loan_id = ?");
                loanBalanceStmt.setInt(1, loan_id);
                ResultSet loanBalanceResult = loanBalanceStmt.executeQuery();

                double loanBalance = 0.0;

                if (loanBalanceResult.next()) {
                    loanBalance = loanBalanceResult.getDouble("loan_balance");
                }

                loanBalanceStmt.close();
                
                // Calculate the new loan balance after deducting the payment amount
                double newLoanBalance = loanBalance - total_payment;

                // Update the loan balance and status in the loan_information table
                PreparedStatement updateLoanInfoStmt = conn.prepareStatement("UPDATE loan_information SET loan_balance = ?, loan_status = ?, date_completed = ? WHERE loan_id = ?");
                updateLoanInfoStmt.setDouble(1, newLoanBalance);
                
                // Check if the new loan balance is zero or less
                if (newLoanBalance <= 0) {
                    updateLoanInfoStmt.setString(2, "completed"); // Set the status to "completed"
                    updateLoanInfoStmt.setDate(3, payment_date); // Set the date_completed to the payment date
                } else {
                    updateLoanInfoStmt.setString(2, "approved"); // Set the status to "approved" if the balance is not zero
                    updateLoanInfoStmt.setDate(3, null); // Set the date_completed to null
                }

                updateLoanInfoStmt.setInt(4, loan_id);
                updateLoanInfoStmt.executeUpdate();

                updateLoanInfoStmt.close();
                pstmt.close();
            } else {
                System.out.println("Payment cannot be added for a loan with status: " + loanStatus);
                return 0; // Payment addition failed
            }

            conn.close();

            return 1; // Successful payment addition
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0; // Payment addition failed
        }
    }
    
    public int get_payment() {
        
        try {
            // 1. Instantiate a connection variable
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM payments WHERE reference_code = ?");
            pstmt.setInt(1, reference_code);
            ResultSet result = pstmt.executeQuery();
            
            if (result.next()) {
                reference_code = result.getInt("reference_code");
                payment_date = result.getDate("payment_date");
                payment_method = result.getString("payment_method");
                total_payment = result.getDouble("total_payment");
                loan_id = result.getInt("loan_id");
                account_id = result.getInt("account_id");
                branch_id = result.getInt("branch_id");
            } else {
                return 0;
            }
        
            conn.close();
            pstmt.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public ArrayList<Integer> list_payments() {

        //ArrayList<Integer> reference_codelist = new ArrayList<> ();

        try {
            // 1. Instantiate a connection variable
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");
            PreparedStatement pstmt = conn.prepareStatement("SELECT reference_code FROM payments ORDER BY reference_code");
            ResultSet results = pstmt.executeQuery();

            reference_codelist.clear();

            while(results.next()) {
                reference_codelist.add(results.getInt("reference_code"));
            }

            pstmt.close();
            conn.close();

            return reference_codelist;
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            return reference_codelist;
        }
    }
    
    public ArrayList<Integer> list_account_id() {

        //ArrayList<Integer> reference_codelist = new ArrayList<> ();

        try {
            // 1. Instantiate a connection variable
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");
            PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT account_id FROM payments ORDER BY account_id");
            ResultSet results = pstmt.executeQuery();

            account_idlist.clear();

            while(results.next()) {
                account_idlist.add(results.getInt("account_id"));
            }

            pstmt.close();
            conn.close();

            return account_idlist;
        } catch(SQLException e) {
            System.out.println(e.getMessage());
            return account_idlist;
        }
    }
    
    public int delete_payment() {
        try {
            // 1. Instantiate a connection variable
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(reference_code) AS count FROM payments WHERE reference_code = ?");
            pstmt.setInt(1, reference_code);
            ResultSet result = pstmt.executeQuery();
            
            int count = 0;
            if (result.next()) 
               count = result.getInt(1);
            
            if (count==0)
                return 2;
                    
            pstmt = conn.prepareStatement("DELETE FROM payments WHERE reference_code = ?");
            pstmt.setInt(1, reference_code);
            pstmt.executeUpdate();
           
            conn.close();
            pstmt.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public ArrayList<Integer> listPaymentsByAccountId(String accountId) {
        ArrayList<Integer> branchIds = new ArrayList<>();

        try {
            Connection conn;     
            // 2. Connect to your DB
            conn = DriverManager.getConnection(database);
            // 3. Indicate a notice of successful connection
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT reference_code FROM payments WHERE account_id = ?");
            pstmt.setString(1, accountId);
            ResultSet results = pstmt.executeQuery();

            reference_codelist.clear();

            while(results.next()) {
                reference_codelist.add(results.getInt("reference_code"));
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return reference_codelist;
    }
    
    public static void main (String[] args) {
        
        // payments P = new payments();
        
        
    }
}

